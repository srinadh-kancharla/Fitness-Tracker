package com.burnboost.fitnesstracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BurnBoostApplication {

    public static void main(String[] args) {
        SpringApplication.run(BurnBoostApplication.class, args);
    }
}